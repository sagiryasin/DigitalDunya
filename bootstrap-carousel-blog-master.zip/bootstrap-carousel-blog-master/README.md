# bootstrap-carousel-blog
Bootstrap Carousel-Blog template is a fully responsive template for Bootstrap lover's,  which include navbar, carousel, horizontal blog and team sections etc - Created by Bootcatch team.

[![bootstrap carousel-blog](https://raw.githubusercontent.com/ajaymarathe/bootstrap-carousel-blog/master/img/carousel_blog.png)](https://ajaymarathe.github.io/bootstrap-carousel-blog/index)


## About

Bootcatch is an open source library of free Bootstrap templates and themes. All of the free templates and themes on Bootcatch are released under the MIT license, which means you can use them for any purpose, even for commercial projects.

* https://ajaymarathe.github.io/bootstrap-carousel-blog/index
* http://bootcatch.com

## Usage

After downloading, you can do whatever you want to do, like you can do changes in CSS and HTML files and make awesome templates as you want.
hope this will help you.

## Clone the Repository -

`git clone https://github.com/ajaymarathe/bootstrap-carousel-blog.git  `

## Author

Ajay Marathe

+ https://github.com/ajaymarathe
+ http://bootcatch.com

## Copyright and License

Copyright 2019 [Ajay Marathe](https://github.com/ajaymarathe). Code released under the [MIT](https://github.com/ajaymarathe/bootstrap-simple-blog/blob/master/LICENSE) license.

